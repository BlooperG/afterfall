using System.Net.Http;
using System.Windows;
using System.Windows.Input;
namespace AFTERFALL.Client;
public partial class MainWindow : Window {
 double x=450,y=280;
 public MainWindow() { InitializeComponent(); Loaded += async (_,_) => { try { using var h=new HttpClient(); var r=await h.GetAsync("http://127.0.0.1:5080/api/health"); StatusText.Text=r.IsSuccessStatusCode?"Сервер подключён":"Сервер недоступен"; } catch { StatusText.Text="Запустите AFTERFALL.Server.exe"; } World.Focus(); }; }
 void World_KeyDown(object sender, KeyEventArgs e) { const double s=12; if(e.Key==Key.W||e.Key==Key.Up)y-=s; if(e.Key==Key.S||e.Key==Key.Down)y+=s; if(e.Key==Key.A||e.Key==Key.Left)x-=s; if(e.Key==Key.D||e.Key==Key.Right)x+=s; x=Math.Clamp(x,0,World.ActualWidth-28); y=Math.Clamp(y,0,World.ActualHeight-28); Canvas.SetLeft(Player,x); Canvas.SetTop(Player,y); }
}