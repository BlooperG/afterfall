using System.Net.Http;
using System.Net.Http.Json;
using System.Windows;
namespace AFTERFALL.Editor;
public partial class MainWindow : Window {
 readonly HttpClient http=new(){BaseAddress=new Uri("http://127.0.0.1:5080"),Timeout=TimeSpan.FromSeconds(3)};
 public MainWindow(){InitializeComponent();Loaded+=async(_,_)=>await Check();}
 async Task Check(){try{var r=await http.GetAsync("/api/health");StatusText.Text=r.IsSuccessStatusCode?"Подключён":"Ошибка сервера";}catch{StatusText.Text="Нет соединения — запустите Server.exe";}}
 async void Check_Click(object sender,RoutedEventArgs e)=>await Check();
 async void Save_Click(object sender,RoutedEventArgs e){try{var p=new{id=IdBox.Text.Trim(),name=NameBox.Text.Trim(),category=CategoryBox.Text.Trim()};var r=await http.PostAsJsonAsync("/api/items",p);ResultText.Text=r.IsSuccessStatusCode?"Предмет сохранён в базе сервера.":"Ошибка сохранения.";}catch{ResultText.Text="Нет соединения с сервером.";}}
}