using Microsoft.Data.Sqlite;
var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://0.0.0.0:5080");
var app = builder.Build();
var dbPath = Path.Combine(AppContext.BaseDirectory, "afterfall.db");
var cs = new SqliteConnectionStringBuilder { DataSource = dbPath }.ToString();
await using (var db = new SqliteConnection(cs))
{
    await db.OpenAsync();
    var cmd = db.CreateCommand();
    cmd.CommandText = "CREATE TABLE IF NOT EXISTS Items (Id TEXT PRIMARY KEY, Name TEXT NOT NULL, Category TEXT NOT NULL, UpdatedUtc TEXT NOT NULL)";
    await cmd.ExecuteNonQueryAsync();
}
app.MapGet("/", () => Results.Ok(new { name = "AFTERFALL Server", status = "online" }));
app.MapGet("/api/health", () => Results.Ok(new { status = "online", utc = DateTime.UtcNow }));
app.MapGet("/api/items", async () => {
    var list = new List<object>();
    await using var db = new SqliteConnection(cs); await db.OpenAsync();
    var cmd = db.CreateCommand(); cmd.CommandText = "SELECT Id, Name, Category FROM Items ORDER BY Name";
    await using var rd = await cmd.ExecuteReaderAsync();
    while (await rd.ReadAsync()) list.Add(new { id = rd.GetString(0), name = rd.GetString(1), category = rd.GetString(2) });
    return Results.Ok(list);
});
app.MapPost("/api/items", async (ItemInput item) => {
    if (string.IsNullOrWhiteSpace(item.Id) || string.IsNullOrWhiteSpace(item.Name)) return Results.BadRequest();
    await using var db = new SqliteConnection(cs); await db.OpenAsync();
    var cmd = db.CreateCommand();
    cmd.CommandText = "INSERT INTO Items(Id,Name,Category,UpdatedUtc) VALUES($id,$name,$cat,$utc) ON CONFLICT(Id) DO UPDATE SET Name=$name,Category=$cat,UpdatedUtc=$utc";
    cmd.Parameters.AddWithValue("$id", item.Id); cmd.Parameters.AddWithValue("$name", item.Name);
    cmd.Parameters.AddWithValue("$cat", item.Category ?? "misc"); cmd.Parameters.AddWithValue("$utc", DateTime.UtcNow.ToString("O"));
    await cmd.ExecuteNonQueryAsync(); return Results.Ok(new { saved = true });
});
app.Run();
record ItemInput(string Id, string Name, string? Category);
