# AFTERFALL — Windows EXE starter

Три отдельных приложения для Windows x64:
- AFTERFALL.Server.exe — ASP.NET Core + SQLite.
- AFTERFALL.Client.exe — WPF top-down prototype.
- AFTERFALL.Editor.exe — WPF editor shell.

Это первый компилируемый каркас, не готовая MMO.

## Сборка без установки инструментов на ПК
Загрузи содержимое архива в чистый GitHub-репозиторий вместе с папкой `.github`.
Открой Actions → Build AFTERFALL Windows EXEs → Run workflow.
Скачай артефакт AFTERFALL-Windows-x64.

Запуск: сначала Server, затем Client и Editor. Адрес по умолчанию: http://127.0.0.1:5080.
Для внешних подключений потребуется настроить Firewall, сетевой адрес и безопасность сервера.
